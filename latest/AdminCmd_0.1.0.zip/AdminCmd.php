<?php

/*
__PocketMine Plugin__
name=AdminCmd
version=0.1.0
author=sekjun9878
class=AdminCmd
*/

class AdminCmd implements Plugin{
	private $api;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("kickall", "[AdminCmd] Kicks all players", array($this, "handleCommand"));
	}
	
	public function __destruct(){
	
	}
	
	public function handleCommand($cmd, $arg){
		switch($cmd){
			case "kickall":
				
				foreach($this->api->player->getAll() as $c){ //$c->username
					
					console("Kicking Player: ".$c->username);
					$c->close("[AdminCmd] KickAll");
				}
				break;
		}
	}

}
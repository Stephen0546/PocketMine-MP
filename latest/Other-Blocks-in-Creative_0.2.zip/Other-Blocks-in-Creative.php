<?php

/*
__PocketMine Plugin__
name=Block Changer Settings
description=You place a Block instead of another Block!!!!!
version=0.2
author=Kivifreak
class=BlockReplacement
*/


class BlockReplacement implements Plugin{
	private $api, $config, $path;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		
		$this->api->addHandler("player.block.action", array($this, "handle"), 30); //Priority higher that API
		$this->api->addHandler("player.equipment.change", array($this, "handle"), 15);
		$this->createConfig();
	}
		public function __destruct(){
	
	}


	
	public function handle(&$data, $event){
	$this->config = $this->readConfig($this->path);
		switch($event){
			case "player.equipment.change":
			if($this->config["Chat Enable"]===true){
				if($data["block"] === $this->config["Block to be changed"]){
					$this->api->player->getByEID($data["eid"])->eventHandler("[Plugin]Remember, you wont place this block, but another!", "server.chat");

				}}
				break;
			case "player.block.action":
			
				if($data["block"] === $this->config["Block to be changed"]){ //no u won't
					$data["block"] = $this->config["Change into"]; //wtf it's a secret LOL
					$data["meta"] = 0;

				}
				break;

		}
		

	}
		        public function createConfig()
        {
                $this->path = $this->api->plugin->createConfig($this, array(
                                "Block to be changed" => "46",
                                "Change into" => "9",
                                "Chat Enable" => false,
                        ));
        }
 public function readConfig($path)
        {
                return $this->api->plugin->readYAML($path."config.yml");
        }
}
<?php
/*
  __PocketMine Plugin__
  name=TrustPlayer
  description=You can't place or break anithing if the admin don't accept you on the server.
  version=0.0.1
  author=InusualZ
  class=TrustPlayer
 */

class TrustPlayer implements Plugin {

    private $api, $path;

    public function __construct(ServerAPI $api, $server = false) {
        $this->api = $api;
    }

    public function init() {
        $this->api->addHandler("player.block.break", array($this, "handle"), 15);
        $this->api->addHandler("player.block.place", array($this, "handle"), 15);
        $this->createConfig();
        $this->api->console->register("trust", "Trust a player", array($this, "commandH"));
        $this->api->console->register("detrust", "Removes trust to a player", array($this, "commandH"));
    }

    public function __destruct() {
        
    }

    public function commandH($cmd, $args) {
        switch ($cmd) {
            case "trust":
                $user = array_shift($args);
                if ($user == null) {
                    console('[INFO] Usage: /trust <player>');
                } else {
                    $this->trust($user);
                }
                break;
            case "detrust":
                $user = array_shift($args);
                if ($user == null) {
                    console('[INFO] Usage: /detrust <player>');
                } else {
                    $this->detrust($user);
                }
                break;
        }
    }

    public function handle(&$data, $event) {
        switch ($event) {
            case "player.block.break":
                $config = $this->readConfig();
                $list = explode(';', $config['user-list']);
                $username = $this->api->player->getByEID($data['eid'])->username;
                if (!in_array($username, $list)) {
                    $block = $this->api->level->getBlock($data['x'], $data['y'], $data['z']);
                    if ($config['send-msg'] === true) {
                        $this->api->player->getByEID($data["eid"])->eventHandler($config['msg-break'], "server.chat");
                    }
                    $this->api->dhandle("world.block.change", array(
                        "x" => $block[2][0],
                        "y" => $block[2][1],
                        "z" => $block[2][2],
                        "block" => $block[0],
                        "meta" => $block[1],
                    ));
                    return false;
                }
                break;
            case "player.block.place":
                $config = $this->readConfig();
                $list = explode(';', $config['user-list']);
                $username = $this->api->player->getByEID($data['eid'])->username;
                if (!in_array($username, $list)) {
                    $block = $this->api->level->getBlock($data['x'], $data['y'], $data['z']);
                    if ($config['send-msg'] === true) {
                        $this->api->player->getByEID($data["eid"])->eventHandler($config['msg-place'], "server.chat");
                    }
                    $this->api->dhandle("world.block.change", array(
                        "x" => $block[2][0],
                        "y" => $block[2][1],
                        "z" => $block[2][2],
                        "block" => $block[0],
                        "meta" => $block[1],
                    ));
                    return false;
                }
                break;
        }
    }

    public function createConfig() {
        $this->path = $this->api->plugin->createConfig($this, array(
            "user-list" => "",
            "send-msg" => true,
            "msg-break" => "[Trust Player] You can't break block, you are not a trust player.",
            "msg-place" => "[Trust Player] You can't place block, you are not a trust payer.",
                ));
    }

    public function readConfig() {
        return $this->api->plugin->readYAML($this->path . "config.yml");
    }

    public function writeConfig($config) {
        if ($this->api->plugin->writeYAML($this->path . "config.yml", $config)) {
            return true;
        } else {
            return false;
        }
    }

    public function trust($username) {
        $config = $this->readConfig();
        $user = $this->api->player->get($username);
        if ($user) {
            if (!in_array($username, explode(';', $config['user-list']))) {
                $userli = $config['user-list'] . $username . ";";
                $config['user-list'] = $userli;
                if ($this->writeConfig($config)) {
                    console('The username has been added to the list.');
                } else {
                    console("The username can't be added to the list.");
                }
            } else {
                console('The username alredy exist on the list.');
            }
        }
    }

    public function detrust($username) {
        $config = $this->readConfig();
        $list = explode(";", $config['user-list']);
        if (in_array($username, $list)) {
            $key = array_search($username, $list);
            unset($list[$key]);
            $config['user-list'] = implode(';', $list);
            if ($this->writeConfig($config)) {
                console('The username has been removed from the list.');
            } else {
                console("The username can't be removed from the list.");
            }
        } else {
            console('Username not found in the list.');
        }
    }

}
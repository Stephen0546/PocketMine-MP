<?php

/*
__PocketMine Plugin__
name=ContestHelper
description=Contest Helper helps you hold Contest Events
version=0.1
author=MinecrafterJPN
class=ContestHelper
*/

class ContestHelper implements Plugin{
	private $api, $user_pos, $user_point;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
                                $this->user_point = array();
                                $this->user_pos = array();
	}
	
	public function init(){                    
                    $this->api->addHandler('player.block.break', array($this, 'handle'), 15);
                    $this->api->addHandler('player.block.place', array($this, 'handle'), 15);
                    $this->api->console->register('setarea', 'ContestHelper Command', array($this, 'command'));
                    $this->api->console->register('ranking', 'ContestHelper Command', array($this, 'command'));    
                }        
                	
	public function __destruct(){

	}
        
                public function command($cmd, $args){
                    switch ($cmd){
                        case "setarea":
                            $player = array_shift($args);
                            if ($player == null) {
                                console('[ALERT] Usage: setarea <player>');                     
                            }else{
                                $this->link($player);
                            }    
                            break;
                        case "ranking":                      
                            $cnt = array_shift($args);
                            if ($cnt == null) {
                                $cnt = 3;
                            }
                            if (!is_numeric($cnt)) {
                                console('[ALERT] Please type a number');
                            } else {
                                arsort($this->user_point);
                                $i = 1;
                                foreach ($this->user_point as $key => $value) {
                                    if ($i > $cnt) {
                                        break;
                                    } else {
                                        console("[RANKING] $i. $key : $value pts");										
                                        $this->api->console->defaultCommands('say', array("[RANKING] $i. $key : $value pts"));
                                        $i ++;
                                    }                                    
                                }
                            }
                            break;
                             
                    }   
                }
                
                public function handle(&$data, $event) {
                    switch ($event) {
                    case 'player.block.break':                        
                        $pos  = array(floor($data['x']), floor($data['z']));
                        if(in_array($pos, $this->user_pos)){                            
                            $gainer = array_search($pos, $this->user_pos);
                            if ($this->user_point[$gainer] > 0) {
                                $this->user_point[$gainer] --;
                                $giver = $this->api->player->getByEID($data['eid'])->username;
                                console("$giver deducted a point from $gainer building!");
                            }                            
                        }                                          
                        break;
                    
                    case 'player.block.place':                        
                        $pos  = array(floor($data['x']), floor($data['z']));
                        if(in_array($pos, $this->user_pos)){
                            $gainer = array_search($pos, $this->user_pos);
                            $this->user_point[$gainer] ++;
                            $giver = $this->api->player->getByEID($data['eid'])->username;
                            console("$giver added a point to $gainer building!");
                        }
                        break;                        
                    }                
                }
                
                public function link($name){
                    $target = $this->api->player->get($name);
                    if ($target == false) {
                        console("$name may not exist");
                    }else {                        
                        $x = floor($target->entity->x);
                        $z = floor($target->entity->z);
                        $this->user_pos[$name] = array($x, $z);
                        $this->user_point[$name] = 0;
                        console("$name has been registered at $x, $z");
                    }                    
                }    
}
<?php

/*
__PocketMine Plugin__
name=WorldEditor
description=World Editor is a port of WorldEdit to PocketMine
version=0.3
author=shoghicp
class=WorldEditor
*/

class WorldEditor implements Plugin{
	private $api, $pos1, $pos2, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->pos1 = false;
		$this->pos2 = false;
	}
	
	public function init(){
		$this->path = $this->api->plugin->createConfig($this, array(
			"default-player" => false, //player ingame
		));	
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
		$this->api->console->register("/", "WorldEditor commands", array($this, "command"));
		if(!method_exists($this->api->console, "alias")){
			$this->api->console->register("/pos1", "WorldEditor commands", array($this, "command"));
			$this->api->console->register("/pos2", "WorldEditor commands", array($this, "command"));
			$this->api->console->register("/set", "WorldEditor commands", array($this, "command"));
			$this->api->console->register("/replace", "WorldEditor commands", array($this, "command"));
			$this->api->console->register("/help", "WorldEditor commands", array($this, "command"));		
		}else{
			$this->api->console->alias("/pos1", "/");
			$this->api->console->alias("/pos2", "/");
			$this->api->console->alias("/set", "/");
			$this->api->console->alias("/replace", "/");
			$this->api->console->alias("/help", "/");
		}
	}
	
	public function __destruct(){

	}
	
	public function command($cmd, $params){
		if($cmd{0} === "/"){
			$cmd = substr($cmd, 1);
		}else{
			console("[WE] Bad command");
		}
		switch($cmd){
			case "pos1":
				$target = trim(implode(" ", $params));
				$target = $target != "" ? $target:$this->config["target-player"];
				
				if(($player = $this->api->player->get($target)) !== false){
					$this->pos1 = array(round($player->entity->x - 0.5), round($player->entity->y), round($player->entity->z - 0.5));
					$count = $this->countBlocks();
					if($count === false){
						$count = "";
					}else{
						$count = " ($count)";
					}
					console("[WE] First position set to (".$this->pos1[0].", ".$this->pos1[1].", ".$this->pos1[2].")$count.");
				}else{
					console("[WE] Target player ".$target." is not connected.");
				}
				break;
			case "pos2":
				$target = trim(implode(" ", $params));
				$target = $target != "" ? $target:$this->config["target-player"];
				
				if(($player = $this->api->player->get($target)) !== false){
					$this->pos2 = array(round($player->entity->x - 0.5), round($player->entity->y), round($player->entity->z - 0.5));
					$count = $this->countBlocks();
					if($count === false){
						$count = "";
					}else{
						$count = " ($count)";
					}
					console("[WE] Second position set to (".$this->pos2[0].", ".$this->pos2[1].", ".$this->pos2[2].")$count.");
				}else{
					console("[WE] Target player ".$target." is not connected.");
				}
				break;
			case "set":
				$params = explode(":", $params[0]);
				if(!isset($params[1])){
					$meta = false;
				}else{
					$meta = ((int) $params[1]) & 0x0F;
				}
				$block = ((int) $params[0]) & 0xFF;
				$this->W_set($block, $meta);
				break;
			case "replace":
				$b1 = explode(":", $params[0]);
				if(!isset($b1[1])){
					$meta1 = false;
				}else{
					$meta1 = ((int) $b1[1]) & 0x0F;
				}
				$block1 = ((int) $b1[0]) & 0xFF;
				
				$b2 = explode(":", $params[1]);
				if(!isset($b2[1])){
					$meta2 = false;
				}else{
					$meta2 = ((int) $b2[1]) & 0x0F;
				}
				$block2 = ((int) $b2[0]) & 0xFF;
				
				$this->W_replace($block1, $meta1, $block2, $meta2);
				break;
			default:
			case "help":
				console("[WE] Commands: //pos1, //pos2, //set, //replace, //help");
				break;
		}
	}
	
	private function countBlocks(){
		if($this->pos1 === false or $this->pos2 === false){
			return false;
		}	
		$startX = min($this->pos1[0], $this->pos2[0]);
		$endX = max($this->pos1[0], $this->pos2[0]);
		$startY = min($this->pos1[1], $this->pos2[1]);
		$endY = max($this->pos1[1], $this->pos2[1]);
		$startZ = min($this->pos1[2], $this->pos2[2]);
		$endZ = max($this->pos1[2], $this->pos2[2]);
		return ($endX - $startX + 1) * ($endY - $startY + 1) * ($endZ - $startZ + 1);
	}
	
	private function W_set($block, $meta){
		if($this->pos1 === false or $this->pos2 === false){
			console("[WE] Make a selection first");
			return false;
		}
		$startX = min($this->pos1[0], $this->pos2[0]);
		$endX = max($this->pos1[0], $this->pos2[0]);
		$startY = min($this->pos1[1], $this->pos2[1]);
		$endY = max($this->pos1[1], $this->pos2[1]);
		$startZ = min($this->pos1[2], $this->pos2[2]);
		$endZ = max($this->pos1[2], $this->pos2[2]);
		$count = ($endX - $startX + 1) * ($endY - $startY + 1) * ($endZ - $startZ + 1);
		console("[WE] $count block(s) have been changed.");
		for($x = $startX; $x <= $endX; ++$x){
			for($y = $startY; $y <= $endY; ++$y){
				for($z = $startZ; $z <= $endZ; ++$z){
					$this->api->level->setBlock($x, $y, $z, $block, ($meta === false ? 0:$meta)); //WARNING!!! Temp. method until I redone chunk sending
				}
			}
		}
		return true;
	}
	
	private function W_replace($block1, $meta1, $block2, $meta2){
		if($this->pos1 === false or $this->pos2 === false){
			console("[WE] Make a selection first");
			return false;
		}
		$startX = min($this->pos1[0], $this->pos2[0]);
		$endX = max($this->pos1[0], $this->pos2[0]);
		$startY = min($this->pos1[1], $this->pos2[1]);
		$endY = max($this->pos1[1], $this->pos2[1]);
		$startZ = min($this->pos1[2], $this->pos2[2]);
		$endZ = max($this->pos1[2], $this->pos2[2]);
		$count = 0; 
		for($x = $startX; $x <= $endX; ++$x){
			for($y = $startY; $y <= $endY; ++$y){
				for($z = $startZ; $z <= $endZ; ++$z){
					$b = $this->api->level->getBlock($x, $y, $z);
					if($b[0] === $block1 and ($meta1 === false or $b[1] === $meta1)){
						++$count;
						$this->api->level->setBlock($x, $y, $z, $block2, ($meta2 === false ? 0:$meta2)); //WARNING!!! Temp. method until I redone chunk sending
					}					
				}
			}
		}
		console("[WE] $count block(s) have been changed.");
		return true;
	}
}
<?
/*
__PocketMine Plugin__
name=Spawn Protector
description=Is a spawn protector, you can't build anything unless you are 100 blocks away from spawn
version=0.0.1
author=InusualZ
class=SpawnProtector
*/

class SpawnProtector implements Plugin
{
	private $api, $spawn, $path;
	public function __construct(ServerAPI $api, $server = false)
	{
        $this->api = $api;
    }

    public function init()
    {
                $this->api->addHandler("player.block.break", array($this, "handle"), 15);
                $this->api->addHandler("player.block.place", array($this, "handle"), 15);
                $this->createConfig();
                $this->config = $this->readConfig();
                $this->spawn = $this->api->level->getSpawn();          
    }

    public function __destruct(){}

    public function handle(&$data, $event)
    {
    	switch ($event) 
    	{
            case "player.block.break":
                if(Utils::distance(array("x" => $this->spawn['x'], "y" => $this->spawn['y'], "z" => $this->spawn['z']), $data) <= $this->config['block-distance'])
                {
                    
                    $block = $this->api->level->getBlock($data['x'], $data['y'], $data['z']);
                    if($this->config['broadcast-msg'] === true)
                    {
                      $this->api->player->getByEID($data["eid"])->eventHandler($this->config['msg-break'], "server.chat");   
                    }
                    $this->api->dhandle("world.block.change", array(
                        "x" => $block[2][0],
                        "y" => $block[2][1],
                        "z" => $block[2][2],
                        "block" => $block[0],
                        "meta" => $block[1],
                    ));
                    return false;
                }
                break;
            case "player.block.place":
                    if(Utils::distance(array("x" => $this->spawn['x'], "y" => $this->spawn['y'], "z" => $this->spawn['z']), $data) <= $this->config['block-distance'])
                    {
                        if($this->config['broadcast-msg'] === true)
                        {
                            $this->api->player->getByEID($data["eid"])->eventHandler($this->config['msg-place'], "server.chat");   
                        }
			$data['block'] = 0;
					
                    }
		break;
    	}
        
    }
    
    public function createConfig()
    {
        $this->path = $this->api->plugin->createConfig($this, array(
            "block-distance" => 20,
            "send-msg" => true,
            "msg-break" => "[Spawn Protector] You can't break block in this area, has to go further.",
            "msg-place" => "[Spawn Protector] You can't place block in this area, has to go further.",            
     ));
    }
     public function readConfig()
    {
                return $this->api->plugin->readYAML($this->path."config.yml");
    }
}
 
?>